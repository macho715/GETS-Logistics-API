from __future__ import annotations


def main() -> str:
    return "it works"
