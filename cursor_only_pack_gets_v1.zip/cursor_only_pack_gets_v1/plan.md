# plan.md (SoT)

## Tests
- [ ] test: scaffold exists (file: src/__init__.py, name: test_scaffold_exists)
- [ ] test: basic function runs (file: src/core/app.py, name: test_app_runs)

## Notes
- Mark passed tests as: - [x] ... # passed @YYYY-MM-DD <commit:abcd1234>
