# HVDC Airtable API ImplSpecPack

Included:
- 43_IMPL__Airtable_API_CallDesign__v1.0__2025-12-24.md
- 44_CODE__python_airtable_client__v1.0__2025-12-24.py
- 45_POSTMAN__HVDC_Airtable_API_Recipes__v1.0.postman_collection.json

Quick run (Python):
1) export AIRTABLE_PAT=...
2) export AIRTABLE_BASE_ID=app...
3) export TABLE_ID_SHIPMENTS=tbl...   (optional)
4) python 44_CODE__python_airtable_client__v1.0__2025-12-24.py
